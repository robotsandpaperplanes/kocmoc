import asyncio
import tempfile
from pathlib import Path

from app.db import Database
from app.models import CertificateStatus


def test_test_certificate_and_redemption_are_unique() -> None:
    async def run() -> None:
        with tempfile.TemporaryDirectory() as directory:
            db = Database(Path(directory) / "test.sqlite3")
            await db.init()
            certificate = await db.issue_test_certificate(
                telegram_user_id=1,
                chat_id=1,
                amount_kopecks=500_000,
                comment="Тест",
                redeem_token="secret-token-1",
            )

            assert certificate.status == CertificateStatus.ACTIVE
            assert len(certificate.id) == 36

            found = await db.get_certificate_by_id_or_code(certificate.id)
            assert found is not None
            assert found.id == certificate.id

            redeemed, changed = await db.redeem_certificate_by_id(
                certificate_id=certificate.id,
                redeemed_by=123,
            )
            assert changed is True
            assert redeemed is not None
            assert redeemed.status == CertificateStatus.REDEEMED
            assert redeemed.redeemed_by == 123

            redeemed_again, changed_again = await db.redeem_certificate_by_id(
                certificate_id=certificate.id,
                redeemed_by=456,
            )
            assert changed_again is False
            assert redeemed_again is not None
            assert redeemed_again.redeemed_by == 123

    asyncio.run(run())
