import asyncio
import tempfile
from pathlib import Path

from app.db import Database
from app.models import CertificateStatus


def test_certificate_is_issued_once() -> None:
    async def run() -> None:
        with tempfile.TemporaryDirectory() as directory:
            db = Database(Path(directory) / "test.sqlite3")
            await db.init()
            order = await db.create_order(
                telegram_user_id=1,
                chat_id=1,
                amount_kopecks=500_000,
                comment="Тест",
            )
            first = await db.complete_payment_and_issue_certificate(
                payload=order.invoice_payload,
                total_amount=500_000,
                telegram_payment_charge_id="tg-1",
                provider_payment_charge_id="provider-1",
                redeem_token="token-1",
            )
            second = await db.complete_payment_and_issue_certificate(
                payload=order.invoice_payload,
                total_amount=500_000,
                telegram_payment_charge_id="tg-1",
                provider_payment_charge_id="provider-1",
                redeem_token="token-2",
            )
            assert first.id == second.id
            assert second.redeem_token == "token-1"

            redeemed = await db.redeem_certificate("token-1")
            assert redeemed is not None
            assert redeemed.status == CertificateStatus.REDEEMED

    asyncio.run(run())
