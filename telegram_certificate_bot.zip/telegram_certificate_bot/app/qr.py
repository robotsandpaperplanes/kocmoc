from io import BytesIO

import qrcode


def create_qr_png(data: str) -> BytesIO:
    image = qrcode.make(data)
    buffer = BytesIO()
    image.save(buffer, format="PNG")
    buffer.seek(0)
    return buffer
