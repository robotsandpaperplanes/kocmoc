from __future__ import annotations

import secrets

from fastapi import Depends, FastAPI, Header, HTTPException, Request, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from .config import Settings
from .db import Database
from .models import CertificateStatus


class RedeemResponse(BaseModel):
    code: str
    amount_kopecks: int
    status: CertificateStatus


def create_api(*, db: Database, settings: Settings) -> FastAPI:
    app = FastAPI(title="Certificate Redemption API", docs_url="/docs")

    def require_admin(x_admin_secret: str = Header(default="")) -> None:
        if not secrets.compare_digest(x_admin_secret, settings.admin_redeem_secret):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/redeem/{token}", response_class=HTMLResponse)
    async def certificate_page(token: str, request: Request) -> HTMLResponse:
        certificate = await db.get_certificate_by_token(token)
        if not certificate:
            return HTMLResponse(_page("Сертификат не найден", "QR-код недействителен."), status_code=404)

        amount = f"{certificate.amount_kopecks // 100:,}".replace(",", " ") + " ₽"
        if certificate.status == CertificateStatus.ACTIVE:
            body = (
                f"Код: <strong>{certificate.public_code}</strong><br>"
                f"Номинал: <strong>{amount}</strong><br>"
                "Статус: <strong>активен</strong>"
            )
            return HTMLResponse(_page("Действующий сертификат", body))

        body = (
            f"Код: <strong>{certificate.public_code}</strong><br>"
            f"Номинал: <strong>{amount}</strong><br>"
            "Статус: <strong>уже использован</strong>"
        )
        return HTMLResponse(_page("Сертификат использован", body), status_code=409)

    @app.post(
        "/api/redeem/{token}",
        response_model=RedeemResponse,
        dependencies=[Depends(require_admin)],
    )
    async def redeem(token: str) -> RedeemResponse:
        certificate = await db.redeem_certificate(token)
        if not certificate:
            raise HTTPException(status_code=404, detail="Certificate not found")
        if certificate.status != CertificateStatus.REDEEMED:
            raise HTTPException(status_code=409, detail="Certificate could not be redeemed")
        return RedeemResponse(
            code=certificate.public_code,
            amount_kopecks=certificate.amount_kopecks,
            status=certificate.status,
        )

    return app


def _page(title: str, body: str) -> str:
    return f"""<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{title}</title>
  <style>
    body {{ font-family: system-ui, sans-serif; max-width: 560px; margin: 48px auto; padding: 0 20px; line-height: 1.5; }}
    .card {{ border: 1px solid #ddd; border-radius: 16px; padding: 24px; }}
  </style>
</head>
<body><div class="card"><h1>{title}</h1><p>{body}</p></div></body>
</html>"""
