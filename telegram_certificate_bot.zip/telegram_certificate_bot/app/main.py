from __future__ import annotations

import asyncio
import logging

import uvicorn
from aiogram import Bot

from .api import create_api
from .bot import setup_handlers
from .config import Settings
from .db import Database


async def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    settings = Settings()
    db = Database(settings.database_path)
    await db.init()

    bot = Bot(token=settings.bot_token)
    dp = setup_handlers(db=db, settings=settings)
    api = create_api(db=db, settings=settings)

    server = uvicorn.Server(
        uvicorn.Config(
            app=api,
            host=settings.host,
            port=settings.port,
            log_level="info",
        )
    )

    try:
        await asyncio.gather(
            dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types()),
            server.serve(),
        )
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
