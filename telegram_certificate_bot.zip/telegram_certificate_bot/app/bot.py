from __future__ import annotations

import json
import logging
import secrets
from html import escape

from aiogram import Bot, Dispatcher, F, Router
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
)

from .config import Settings
from .db import Database
from .keyboards import (
    AMOUNT_KEYBOARD,
    COMMENT_CONFIRM_KEYBOARD,
    COMMENT_ENTRY_KEYBOARD,
    MAIN_MENU,
)
from .qr import create_qr_png
from .states import CertificateFlow

logger = logging.getLogger(__name__)
router = Router()

ALLOWED_AMOUNTS = {500_000, 1_000_000, 2_000_000}
MAX_COMMENT_LENGTH = 500


def format_rubles(kopecks: int) -> str:
    return f"{kopecks // 100:,}".replace(",", " ") + " ₽"


def setup_handlers(*, db: Database, settings: Settings) -> Dispatcher:
    dp = Dispatcher()
    dp["db"] = db
    dp["settings"] = settings
    dp.include_router(router)
    return dp


@router.message(CommandStart())
async def start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Выберите раздел:", reply_markup=MAIN_MENU)


@router.message(F.text.in_({"menu_item_1", "menu_item_2"}))
async def empty_menu_item(message: Message) -> None:
    await message.answer("Раздел пока пуст.", reply_markup=MAIN_MENU)


@router.message(F.text == "Сертификат")
async def certificate_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Выберите номинал сертификата:", reply_markup=AMOUNT_KEYBOARD)


@router.callback_query(F.data.startswith("certificate_amount:"))
async def choose_amount(callback: CallbackQuery, state: FSMContext) -> None:
    _, raw_amount = callback.data.split(":", maxsplit=1)
    try:
        amount = int(raw_amount)
    except ValueError:
        await callback.answer("Некорректный номинал", show_alert=True)
        return
    if amount not in ALLOWED_AMOUNTS:
        await callback.answer("Такой номинал недоступен", show_alert=True)
        return

    await state.set_state(CertificateFlow.waiting_for_comment)
    await state.update_data(amount_kopecks=amount, draft_comment=None)
    await callback.message.edit_text(
        f"Номинал: <b>{format_rubles(amount)}</b>\n\n"
        "Введите комментарий для сертификата или нажмите «Пропустить».\n"
        f"Максимальная длина — {MAX_COMMENT_LENGTH} символов.",
        parse_mode=ParseMode.HTML,
        reply_markup=COMMENT_ENTRY_KEYBOARD,
    )
    await callback.answer()


@router.message(CertificateFlow.waiting_for_comment, F.text)
async def receive_comment(message: Message, state: FSMContext) -> None:
    comment = message.text.strip()
    if not comment:
        await message.answer("Комментарий не может быть пустым.")
        return
    if len(comment) > MAX_COMMENT_LENGTH:
        await message.answer(
            f"Комментарий слишком длинный: {len(comment)} символов. "
            f"Допустимо не более {MAX_COMMENT_LENGTH}."
        )
        return

    await state.update_data(draft_comment=comment)
    await state.set_state(CertificateFlow.confirming_comment)
    await message.answer(
        "Комментарий:\n\n"
        f"<blockquote>{escape(comment)}</blockquote>\n"
        "Сохранить его в сертификате?",
        parse_mode=ParseMode.HTML,
        reply_markup=COMMENT_CONFIRM_KEYBOARD,
    )


@router.callback_query(F.data == "comment:edit")
async def edit_comment(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(CertificateFlow.waiting_for_comment)
    await callback.message.edit_text(
        "Введите новый комментарий или нажмите «Пропустить».",
        reply_markup=COMMENT_ENTRY_KEYBOARD,
    )
    await callback.answer()


@router.callback_query(F.data.in_({"comment:save", "comment:skip"}))
async def finalize_comment(
    callback: CallbackQuery,
    state: FSMContext,
    db: Database,
    settings: Settings,
) -> None:
    data = await state.get_data()
    amount = data.get("amount_kopecks")
    if amount not in ALLOWED_AMOUNTS:
        await callback.answer("Сессия устарела. Начните заново.", show_alert=True)
        await state.clear()
        return

    comment: str | None = None
    if callback.data == "comment:save":
        comment = data.get("draft_comment")
        if not comment:
            await callback.answer("Сначала введите комментарий", show_alert=True)
            return

    order = await db.create_order(
        telegram_user_id=callback.from_user.id,
        chat_id=callback.message.chat.id,
        amount_kopecks=amount,
        comment=comment,
    )

    await callback.message.edit_text(
        f"Сертификат на <b>{format_rubles(amount)}</b> подготовлен. "
        "Перейдите к оплате в счёте ниже.",
        parse_mode=ParseMode.HTML,
    )

    await callback.bot.send_invoice(
        chat_id=callback.message.chat.id,
        title=f"Подарочный сертификат {format_rubles(amount)}",
        description="После успешной оплаты бот отправит уникальный QR-код.",
        payload=order.invoice_payload,
        provider_token=settings.payment_provider_token,
        currency="RUB",
        prices=[LabeledPrice(label="Подарочный сертификат", amount=amount)],
        start_parameter=f"certificate-{order.id}",
        protect_content=True,
    )
    await db.mark_invoiced(order.id)
    await state.clear()
    await callback.answer()


@router.callback_query(F.data == "certificate:cancel")
async def cancel_certificate(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text("Оформление сертификата отменено.")
    await callback.message.answer("Выберите раздел:", reply_markup=MAIN_MENU)
    await callback.answer()


@router.pre_checkout_query()
async def pre_checkout(pre_checkout_query: PreCheckoutQuery, db: Database) -> None:
    order = await db.get_order_by_payload(pre_checkout_query.invoice_payload)
    error: str | None = None
    if not order:
        error = "Заказ не найден. Создайте сертификат заново."
    elif pre_checkout_query.currency != "RUB":
        error = "Некорректная валюта платежа."
    elif pre_checkout_query.total_amount != order.amount_kopecks:
        error = "Сумма платежа не совпадает с заказом."
    elif pre_checkout_query.from_user.id != order.telegram_user_id:
        error = "Этот счёт создан для другого пользователя."

    await pre_checkout_query.answer(ok=error is None, error_message=error)


@router.message(F.successful_payment)
async def successful_payment(message: Message, db: Database, settings: Settings) -> None:
    payment = message.successful_payment
    if payment is None:
        return
    if payment.currency != "RUB":
        logger.error("Unexpected payment currency: %s", payment.currency)
        await message.answer("Платёж получен, но возникла ошибка проверки валюты. Обратитесь в поддержку.")
        return

    try:
        certificate = await db.complete_payment_and_issue_certificate(
            payload=payment.invoice_payload,
            total_amount=payment.total_amount,
            telegram_payment_charge_id=payment.telegram_payment_charge_id,
            provider_payment_charge_id=payment.provider_payment_charge_id,
            redeem_token=secrets.token_urlsafe(32),
        )
    except ValueError:
        logger.exception("Could not issue certificate for payload=%s", payment.invoice_payload)
        await message.answer("Платёж получен, но сертификат не выпущен автоматически. Обратитесь в поддержку.")
        return

    redeem_url = f"{settings.certificate_base_url_str}/redeem/{certificate.redeem_token}"
    qr_buffer = create_qr_png(redeem_url)
    qr_file = BufferedInputFile(qr_buffer.read(), filename=f"{certificate.public_code}.png")

    comment_block = ""
    if certificate.comment:
        comment_block = f"\nКомментарий: <i>{escape(certificate.comment)}</i>"

    await message.answer_photo(
        photo=qr_file,
        caption=(
            "<b>Оплата прошла успешно</b>\n\n"
            f"Сертификат: <code>{certificate.public_code}</code>\n"
            f"Номинал: <b>{format_rubles(certificate.amount_kopecks)}</b>"
            f"{comment_block}\n\n"
            "QR-код уникален. Не публикуйте его: предъявитель сможет использовать сертификат."
        ),
        parse_mode=ParseMode.HTML,
        protect_content=True,
        reply_markup=MAIN_MENU,
    )
