from pathlib import Path

from pydantic import Field, HttpUrl, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    bot_token: str = Field(alias="BOT_TOKEN")
    payment_provider_token: str = Field(alias="PAYMENT_PROVIDER_TOKEN")
    database_path: Path = Field(default=Path("./data/bot.sqlite3"), alias="DATABASE_PATH")
    certificate_base_url: HttpUrl = Field(alias="CERTIFICATE_BASE_URL")
    admin_redeem_secret: str = Field(alias="ADMIN_REDEEM_SECRET", min_length=24)
    host: str = Field(default="0.0.0.0", alias="HOST")
    port: int = Field(default=8080, alias="PORT", ge=1, le=65535)

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @field_validator("bot_token", "payment_provider_token")
    @classmethod
    def validate_token(cls, value: str) -> str:
        value = value.strip()
        if not value or "replace" in value.lower():
            raise ValueError("Укажите реальный токен в .env")
        return value

    @property
    def certificate_base_url_str(self) -> str:
        return str(self.certificate_base_url).rstrip("/")
