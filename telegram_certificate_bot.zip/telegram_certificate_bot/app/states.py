from aiogram.fsm.state import State, StatesGroup


class CertificateFlow(StatesGroup):
    waiting_for_comment = State()
    confirming_comment = State()
