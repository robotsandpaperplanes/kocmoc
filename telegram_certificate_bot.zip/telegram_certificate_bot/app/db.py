from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

import aiosqlite

from .models import Certificate, CertificateStatus, Order, OrderStatus


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path

    async def init(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        async with aiosqlite.connect(self.path) as db:
            await db.execute("PRAGMA journal_mode=WAL")
            await db.execute("PRAGMA foreign_keys=ON")
            await db.executescript(
                """
                CREATE TABLE IF NOT EXISTS orders (
                    id TEXT PRIMARY KEY,
                    telegram_user_id INTEGER NOT NULL,
                    chat_id INTEGER NOT NULL,
                    amount_kopecks INTEGER NOT NULL CHECK(amount_kopecks > 0),
                    comment TEXT,
                    status TEXT NOT NULL,
                    invoice_payload TEXT NOT NULL UNIQUE,
                    telegram_payment_charge_id TEXT UNIQUE,
                    provider_payment_charge_id TEXT UNIQUE,
                    created_at TEXT NOT NULL,
                    paid_at TEXT
                );

                CREATE TABLE IF NOT EXISTS certificates (
                    id TEXT PRIMARY KEY,
                    order_id TEXT NOT NULL UNIQUE REFERENCES orders(id),
                    public_code TEXT NOT NULL UNIQUE,
                    redeem_token TEXT NOT NULL UNIQUE,
                    amount_kopecks INTEGER NOT NULL CHECK(amount_kopecks > 0),
                    comment TEXT,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    redeemed_at TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_certificates_token
                    ON certificates(redeem_token);
                """
            )
            await db.commit()

    async def create_order(
        self,
        *,
        telegram_user_id: int,
        chat_id: int,
        amount_kopecks: int,
        comment: str | None,
    ) -> Order:
        order_id = str(uuid4())
        payload = f"certificate:{order_id}"
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """
                INSERT INTO orders (
                    id, telegram_user_id, chat_id, amount_kopecks, comment,
                    status, invoice_payload, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    order_id,
                    telegram_user_id,
                    chat_id,
                    amount_kopecks,
                    comment,
                    OrderStatus.CREATED.value,
                    payload,
                    utc_now(),
                ),
            )
            await db.commit()
        return Order(
            id=order_id,
            telegram_user_id=telegram_user_id,
            chat_id=chat_id,
            amount_kopecks=amount_kopecks,
            comment=comment,
            status=OrderStatus.CREATED,
            invoice_payload=payload,
        )

    async def mark_invoiced(self, order_id: str) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "UPDATE orders SET status = ? WHERE id = ? AND status = ?",
                (OrderStatus.INVOICED.value, order_id, OrderStatus.CREATED.value),
            )
            await db.commit()

    async def get_order_by_payload(self, payload: str) -> Order | None:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                "SELECT * FROM orders WHERE invoice_payload = ?",
                (payload,),
            )
            row = await cursor.fetchone()
        return self._order_from_row(row) if row else None

    async def complete_payment_and_issue_certificate(
        self,
        *,
        payload: str,
        total_amount: int,
        telegram_payment_charge_id: str,
        provider_payment_charge_id: str,
        redeem_token: str,
    ) -> Certificate:
        """Atomically records a payment and creates exactly one certificate."""
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            await db.execute("BEGIN IMMEDIATE")
            cursor = await db.execute(
                "SELECT * FROM orders WHERE invoice_payload = ?",
                (payload,),
            )
            order_row = await cursor.fetchone()
            if not order_row:
                await db.rollback()
                raise ValueError("Заказ не найден")
            if order_row["amount_kopecks"] != total_amount:
                await db.rollback()
                raise ValueError("Сумма платежа не совпадает с заказом")

            existing_cursor = await db.execute(
                "SELECT * FROM certificates WHERE order_id = ?",
                (order_row["id"],),
            )
            existing = await existing_cursor.fetchone()
            if existing:
                await db.commit()
                return self._certificate_from_row(existing)

            await db.execute(
                """
                UPDATE orders
                SET status = ?, telegram_payment_charge_id = ?,
                    provider_payment_charge_id = ?, paid_at = ?
                WHERE id = ?
                """,
                (
                    OrderStatus.PAID.value,
                    telegram_payment_charge_id,
                    provider_payment_charge_id,
                    utc_now(),
                    order_row["id"],
                ),
            )

            certificate_id = str(uuid4())
            public_code = self._public_code(certificate_id)
            created_at = utc_now()
            await db.execute(
                """
                INSERT INTO certificates (
                    id, order_id, public_code, redeem_token, amount_kopecks,
                    comment, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    certificate_id,
                    order_row["id"],
                    public_code,
                    redeem_token,
                    order_row["amount_kopecks"],
                    order_row["comment"],
                    CertificateStatus.ACTIVE.value,
                    created_at,
                ),
            )
            await db.commit()

        return Certificate(
            id=certificate_id,
            order_id=order_row["id"],
            public_code=public_code,
            redeem_token=redeem_token,
            amount_kopecks=order_row["amount_kopecks"],
            comment=order_row["comment"],
            status=CertificateStatus.ACTIVE,
        )

    async def get_certificate_by_token(self, token: str) -> Certificate | None:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                "SELECT * FROM certificates WHERE redeem_token = ?",
                (token,),
            )
            row = await cursor.fetchone()
        return self._certificate_from_row(row) if row else None

    async def redeem_certificate(self, token: str) -> Certificate | None:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            await db.execute("BEGIN IMMEDIATE")
            cursor = await db.execute(
                "SELECT * FROM certificates WHERE redeem_token = ?",
                (token,),
            )
            row = await cursor.fetchone()
            if not row:
                await db.rollback()
                return None
            if row["status"] == CertificateStatus.ACTIVE.value:
                await db.execute(
                    """
                    UPDATE certificates
                    SET status = ?, redeemed_at = ?
                    WHERE redeem_token = ? AND status = ?
                    """,
                    (
                        CertificateStatus.REDEEMED.value,
                        utc_now(),
                        token,
                        CertificateStatus.ACTIVE.value,
                    ),
                )
                await db.commit()
                return Certificate(
                    id=row["id"],
                    order_id=row["order_id"],
                    public_code=row["public_code"],
                    redeem_token=row["redeem_token"],
                    amount_kopecks=row["amount_kopecks"],
                    comment=row["comment"],
                    status=CertificateStatus.REDEEMED,
                )
            await db.commit()
            return self._certificate_from_row(row)

    @staticmethod
    def _public_code(certificate_id: str) -> str:
        return f"CERT-{certificate_id.replace('-', '')[:12].upper()}"

    @staticmethod
    def _order_from_row(row: aiosqlite.Row) -> Order:
        return Order(
            id=row["id"],
            telegram_user_id=row["telegram_user_id"],
            chat_id=row["chat_id"],
            amount_kopecks=row["amount_kopecks"],
            comment=row["comment"],
            status=OrderStatus(row["status"]),
            invoice_payload=row["invoice_payload"],
            telegram_payment_charge_id=row["telegram_payment_charge_id"],
            provider_payment_charge_id=row["provider_payment_charge_id"],
        )

    @staticmethod
    def _certificate_from_row(row: aiosqlite.Row) -> Certificate:
        return Certificate(
            id=row["id"],
            order_id=row["order_id"],
            public_code=row["public_code"],
            redeem_token=row["redeem_token"],
            amount_kopecks=row["amount_kopecks"],
            comment=row["comment"],
            status=CertificateStatus(row["status"]),
        )
