from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup


MAIN_MENU = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="menu_item_1"), KeyboardButton(text="menu_item_2")],
        [KeyboardButton(text="Сертификат")],
    ],
    resize_keyboard=True,
    input_field_placeholder="Выберите раздел",
)

AMOUNT_KEYBOARD = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="5 000 ₽", callback_data="certificate_amount:500000")],
        [InlineKeyboardButton(text="10 000 ₽", callback_data="certificate_amount:1000000")],
        [InlineKeyboardButton(text="20 000 ₽", callback_data="certificate_amount:2000000")],
    ]
)

COMMENT_ENTRY_KEYBOARD = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="Пропустить", callback_data="comment:skip")],
        [InlineKeyboardButton(text="Отмена", callback_data="certificate:cancel")],
    ]
)

COMMENT_CONFIRM_KEYBOARD = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="Сохранить комментарий", callback_data="comment:save")],
        [InlineKeyboardButton(text="Пропустить", callback_data="comment:skip")],
        [InlineKeyboardButton(text="Изменить", callback_data="comment:edit")],
        [InlineKeyboardButton(text="Отмена", callback_data="certificate:cancel")],
    ]
)
